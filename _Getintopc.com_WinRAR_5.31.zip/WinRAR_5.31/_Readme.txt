Instructions:
1) Stop the application if started
2) Install application using provided installer and do not reboot
3) Close Winrar and Copy Crack file to install directory ( ease of access right click desktop icon and open file location )
DONE!
 


