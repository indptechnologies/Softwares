Use keygen to register software

